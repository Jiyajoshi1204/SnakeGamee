package Snakegame;
import javax.swing.*;

	



	public class snakegame extends JFrame {
	    
	    snakegame() {
	        super("Snake Game- Jiya");
	        add(new content());
	        pack();
	        
	        setLocationRelativeTo(null);
	        setResizable(false);
	    }

	    public static void main(String[] args) {
	        new snakegame().setVisible(true);
	    }
	}

